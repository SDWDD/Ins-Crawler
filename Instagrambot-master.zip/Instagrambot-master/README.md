# Instagrambot
A script to get the texts of the tag from Instagram.com
运行环境：Windows python3.6 
由于一边尝试一边写，引入了一堆没用到的包，见谅见谅~